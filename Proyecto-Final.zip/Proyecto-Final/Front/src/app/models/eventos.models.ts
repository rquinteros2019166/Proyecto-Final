export class Events{
  constructor(
    public _id: String,
    public nameEvent: String,
    public descriptionEvent: String,
    public statusEvent: String,
    public typeEvent: String,
    public dateEvent: String,
    public userEvent: String
  ){}
}
