export interface Post{
  _id: String,
  titlePost: String,
  imagePost: String,
  descriptionPost: String,
  datePost: any,
  tagsPost: String,
  adminPost: String
}
