export class User{
  constructor(
    public _id: String,
    public nickUser: String,
    public fullNameUser: String,
    public emailUser: String,
    public phoneUser: Number,
    public addressUser: String,
    public passwordUser: String,
    public imageUser: String,
    public buysUser: any,
    public rolUser: String
  ){}
}
