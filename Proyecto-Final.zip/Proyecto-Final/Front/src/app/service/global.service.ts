export var GLOBAL = {
  url: 'http://localhost:3000/api/'
}

